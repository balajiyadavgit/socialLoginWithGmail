//
//  ViewController.swift
//  socialGmail
//
//  Created by vaibhav mandiram on 20/03/19.
//  Copyright © 2019 vaibhav mandiram. All rights reserved.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController,GIDSignInDelegate,GIDSignInUIDelegate {
  
    
    
    @IBOutlet weak var textLbl: UILabel!
    
    @IBOutlet weak var enterBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        enterBtn.addTarget(self, action: #selector(signInWithGoogle(_:)), for: UIControl.Event.touchUpInside)
        // Do any additional setup after loading the view, typically from a nib.
    }


    @objc func signInWithGoogle(_ sender:UIButton){
        
        if enterBtn.title(for: UIControl.State.normal) == "signout"{
            GIDSignIn.sharedInstance()?.signOut() 
        }else{
        GIDSignIn.sharedInstance()?.delegate = self
        GIDSignIn.sharedInstance()?.uiDelegate = self
        GIDSignIn.sharedInstance()?.signIn()
        
        }
        
    }

    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        
        if let error = error{
            
            print("got error while signin\(error.localizedDescription)")
        }else{
            
            if let gmailUser = user{
            textLbl.text = "youre signing using id\(gmailUser.profile.email)"
              enterBtn.setTitle("signout", for: UIControl.State.normal)
                
                
            }
            
            
            
        }
        
    }


}




